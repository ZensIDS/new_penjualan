<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->isSuperadmin();
    }

    public function rules(): array
    {
        $product = $this->route('product');

        // qty_on_hand tetap tidak boleh diedit manual di sini.
        return [
            'category_id' => ['required', 'exists:categories,id'],
            'sku'         => ['required', 'string', 'max:255', Rule::unique('products', 'sku')->ignore($product)],
            'name'        => ['required', 'string', 'max:255'],
            'unit'        => ['nullable', 'string', 'max:50'],
            'description' => ['nullable', 'string', 'max:1000'],
            'is_active'   => ['boolean'],
        ];
    }
}
