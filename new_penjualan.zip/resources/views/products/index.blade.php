@extends('layouts.app')

@section('page-title', 'Produk')

@section('content')
<div
    x-data="productPage({{ Illuminate\Support\Js::from($categories) }})"
    x-cloak
>
    <div class="flex items-center justify-between mb-6">
        <p class="text-sm text-ink/50">{{ $products->total() }} produk</p>

        @if (auth()->user()->isSuperadmin())
            <button
                @click="openCreate()"
                class="text-sm font-medium bg-ink text-white px-4 py-2 hover:bg-ink/85 transition-colors"
            >
                + Tambah Produk
            </button>
        @endif
    </div>

    <div x-show="flash" x-cloak class="mb-4 border text-sm px-4 py-3"
         :class="flashType === 'error' ? 'border-red-900/20 bg-red-50 text-red-900' : 'border-ink/10 bg-ink/[0.03]'">
        <span x-text="flash"></span>
    </div>

    <div class="border border-ink/10 overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-ink/10 text-left text-ink/50">
                    <th class="px-4 py-3 font-medium">SKU</th>
                    <th class="px-4 py-3 font-medium">Nama</th>
                    <th class="px-4 py-3 font-medium">Kategori</th>
                    <th class="px-4 py-3 font-medium">Satuan</th>
                    <th class="px-4 py-3 font-medium">Stok</th>
                    <th class="px-4 py-3 font-medium">Status</th>
                    <th class="px-4 py-3 font-medium text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($products as $product)
                    <tr class="border-b border-ink/10 last:border-0">
                        <td class="px-4 py-3 text-ink/50">{{ $product->sku }}</td>
                        <td class="px-4 py-3">{{ $product->name }}</td>
                        <td class="px-4 py-3">{{ $product->category->name }}</td>
                        <td class="px-4 py-3">{{ $product->unit }}</td>
                        <td class="px-4 py-3 tnum">{{ $product->qty_on_hand }}</td>
                        <td class="px-4 py-3">
                            <span class="{{ $product->is_active ? 'text-ink' : 'text-ink/35' }}">
                                {{ $product->is_active ? 'Aktif' : 'Nonaktif' }}
                            </span>
                        </td>
                        <td class="px-4 py-3 text-right">
                            @if (auth()->user()->isSuperadmin())
                                <button
                                    @click="openEdit({{ Illuminate\Support\Js::from($product) }})"
                                    class="text-ink/60 hover:text-ink mr-3"
                                >Edit</button>
                                <button
                                    @click="remove({{ $product->id }})"
                                    class="text-red-800/70 hover:text-red-900"
                                >Hapus</button>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="px-4 py-6 text-center text-ink/40">Belum ada produk.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        {{ $products->links() }}
    </div>

    {{-- Modal Create/Edit --}}
    <div
        x-show="modalOpen"
        x-cloak
        class="fixed inset-0 z-50 flex items-center justify-center px-4"
    >
        <div @click="modalOpen = false" class="absolute inset-0 bg-black/40"></div>

        <div class="relative bg-white border border-ink/10 w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
            <h2 class="font-display font-semibold text-lg mb-4" x-text="editing ? 'Edit Produk' : 'Tambah Produk'"></h2>

            <form @submit.prevent="submit()">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Kategori</label>
                        <select x-model="form.category_id"
                                class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                            <option value="">— Pilih kategori —</option>
                            <template x-for="cat in categories" :key="cat.id">
                                <option :value="cat.id" x-text="cat.name"></option>
                            </template>
                        </select>
                        <p class="text-xs text-red-800 mt-1" x-text="errors.category_id?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">SKU</label>
                        <input type="text" x-model="form.sku"
                               class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                        <p class="text-xs text-red-800 mt-1" x-text="errors.sku?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">Nama</label>
                        <input type="text" x-model="form.name"
                               class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                        <p class="text-xs text-red-800 mt-1" x-text="errors.name?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">Satuan</label>
                        <input type="text" x-model="form.unit" placeholder="pcs"
                               class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                        <p class="text-xs text-red-800 mt-1" x-text="errors.unit?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">Deskripsi</label>
                        <textarea x-model="form.description" rows="3"
                                  class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40"></textarea>
                        <p class="text-xs text-red-800 mt-1" x-text="errors.description?.[0]"></p>
                    </div>

                    <label class="flex items-center gap-2 text-sm">
                        <input type="checkbox" x-model="form.is_active" class="border-ink/15">
                        Produk aktif
                    </label>
                </div>

                <div class="mt-6 flex justify-end gap-2">
                    <button type="button" @click="modalOpen = false"
                            class="text-sm px-4 py-2 border border-ink/15 hover:bg-ink/[0.03]">Batal</button>
                    <button type="submit" :disabled="saving"
                            class="text-sm px-4 py-2 bg-ink text-white hover:bg-ink/85 disabled:opacity-50">
                        <span x-text="saving ? 'Menyimpan...' : 'Simpan'"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function productPage(initialCategories) {
        return {
            categories: initialCategories,
            modalOpen: false,
            editing: null,
            saving: false,
            errors: {},
            flash: null,
            flashType: 'success',
            form: { category_id: '', sku: '', name: '', unit: 'pcs', description: '', is_active: true },

            openCreate() {
                this.editing = null;
                this.form = { category_id: '', sku: '', name: '', unit: 'pcs', description: '', is_active: true };
                this.errors = {};
                this.modalOpen = true;
            },

            openEdit(product) {
                this.editing = product;
                this.form = {
                    category_id: product.category_id,
                    sku: product.sku,
                    name: product.name,
                    unit: product.unit,
                    description: product.description,
                    is_active: !!product.is_active,
                };
                this.errors = {};
                this.modalOpen = true;
            },

            async submit() {
                this.saving = true;
                this.errors = {};

                const url = this.editing
                    ? `{{ url('products') }}/${this.editing.id}`
                    : `{{ route('products.store') }}`;
                const method = this.editing ? 'PUT' : 'POST';

                const { ok, status, data } = await window.ajaxSend(url, method, this.form);
                this.saving = false;

                if (ok) {
                    this.modalOpen = false;
                    this.flashType = 'success';
                    this.flash = data.message;
                    setTimeout(() => window.location.reload(), 500);
                    return;
                }

                if (status === 422) {
                    this.errors = data.errors || {};
                    return;
                }

                this.flashType = 'error';
                this.flash = data.message || 'Terjadi kesalahan.';
            },

            async remove(id) {
                if (!confirm('Hapus produk ini?')) return;

                const { ok, data } = await window.ajaxSend(`{{ url('products') }}/${id}`, 'DELETE');

                this.flashType = ok ? 'success' : 'error';
                this.flash = data.message || (ok ? 'Berhasil dihapus.' : 'Gagal menghapus.');

                if (ok) setTimeout(() => window.location.reload(), 500);
            },
        };
    }
</script>
@endpush
