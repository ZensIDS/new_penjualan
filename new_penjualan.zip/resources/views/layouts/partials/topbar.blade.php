<header class="h-16 border-b border-ink/10 flex items-center justify-between px-4 sm:px-6 lg:px-10 shrink-0">
    <div class="flex items-center gap-4">
        {{-- Hamburger, hanya tampil di mobile --}}
        <button
            @click="sidebarOpen = true"
            class="lg:hidden -ml-1 p-2 text-ink/70 hover:text-ink"
            aria-label="Buka menu"
        >
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.75">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5M3.75 17.25h16.5" />
            </svg>
        </button>

        <h1 class="font-display font-semibold text-lg tracking-tight">
            @yield('page-title', 'Dashboard')
        </h1>
    </div>

    <div class="flex items-center gap-3 text-sm text-ink/50 tnum">
        {{ now()->translatedFormat('l, d F Y') }}
    </div>
</header>
