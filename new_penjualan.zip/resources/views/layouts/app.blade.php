<!DOCTYPE html>
<html lang="id" x-data="{ sidebarOpen: false }" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') — Inventaris</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        display: ['"Space Grotesk"', 'sans-serif'],
                        sans: ['Inter', 'sans-serif'],
                    },
                    colors: {
                        ink: '#111214',
                        paper: '#FFFFFF',
                    },
                },
            },
        }
    </script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>
        /* Angka finansial rapi sejajar */
        .tnum { font-variant-numeric: tabular-nums; }
        [x-cloak] { display: none !important; }
    </style>

    <script>
        // Helper AJAX kecil dipakai semua modal CRUD (products, categories, dst).
        // Mengembalikan { ok, status, data } supaya gampang dicek di Alpine.
        window.ajaxSend = async function (url, method, payload) {
            const res = await fetch(url, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                },
                body: payload ? JSON.stringify(payload) : undefined,
            });

            let data = {};
            try { data = await res.json(); } catch (e) { /* no body */ }

            return { ok: res.ok, status: res.status, data };
        };
    </script>

    @stack('styles')
</head>
<body class="h-full bg-paper text-ink font-sans antialiased">
    <div class="min-h-full lg:flex">

        {{-- Overlay untuk mobile saat sidebar terbuka --}}
        <div
            x-show="sidebarOpen"
            x-cloak
            @click="sidebarOpen = false"
            class="fixed inset-0 z-30 bg-black/40 lg:hidden"
        ></div>

        @include('layouts.partials.sidebar')

        <div class="flex-1 flex flex-col min-w-0">
            @include('layouts.partials.topbar')

            <main class="flex-1 px-4 sm:px-6 lg:px-10 py-8">
                <div class="max-w-6xl mx-auto">

                    @if (session('success'))
                        <div class="mb-6 border border-ink/10 bg-ink/[0.03] text-sm px-4 py-3 flex items-center justify-between">
                            <span>{{ session('success') }}</span>
                        </div>
                    @endif

                    @if ($errors->any())
                        <div class="mb-6 border border-red-900/20 bg-red-50 text-red-900 text-sm px-4 py-3">
                            <p class="font-medium mb-1">Terjadi kesalahan:</p>
                            <ul class="list-disc list-inside space-y-0.5">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    @yield('content')

                </div>
            </main>
        </div>
    </div>

    @stack('scripts')
</body>
</html>
