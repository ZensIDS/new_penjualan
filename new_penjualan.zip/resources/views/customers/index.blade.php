@extends('layouts.app')

@section('page-title', 'Customer')

@section('content')
<div
    x-data="customerPage()"
    x-cloak
>
    <div class="flex items-center justify-between mb-6">
        <p class="text-sm text-ink/50">{{ $customers->total() }} customer</p>

        @if (auth()->user()->isSuperadmin())
            <button
                @click="openCreate()"
                class="text-sm font-medium bg-ink text-white px-4 py-2 hover:bg-ink/85 transition-colors"
            >
                + Tambah Customer
            </button>
        @endif
    </div>

    <div x-show="flash" x-cloak class="mb-4 border text-sm px-4 py-3"
         :class="flashType === 'error' ? 'border-red-900/20 bg-red-50 text-red-900' : 'border-ink/10 bg-ink/[0.03]'">
        <span x-text="flash"></span>
    </div>

    <div class="border border-ink/10 overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-ink/10 text-left text-ink/50">
                    <th class="px-4 py-3 font-medium">Nama</th>
                    <th class="px-4 py-3 font-medium">Telepon</th>
                    <th class="px-4 py-3 font-medium">Email</th>
                    <th class="px-4 py-3 font-medium text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($customers as $customer)
                    <tr class="border-b border-ink/10 last:border-0">
                        <td class="px-4 py-3">{{ $customer->name }}</td>
                        <td class="px-4 py-3 text-ink/50">{{ $customer->phone ?? '—' }}</td>
                        <td class="px-4 py-3 text-ink/50">{{ $customer->email ?? '—' }}</td>
                        <td class="px-4 py-3 text-right">
                            @if (auth()->user()->isSuperadmin())
                                <button
                                    @click="openEdit({{ Illuminate\Support\Js::from($customer) }})"
                                    class="text-ink/60 hover:text-ink mr-3"
                                >Edit</button>
                                <button
                                    @click="remove({{ $customer->id }})"
                                    class="text-red-800/70 hover:text-red-900"
                                >Hapus</button>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="px-4 py-6 text-center text-ink/40">Belum ada customer.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        {{ $customers->links() }}
    </div>

    {{-- Modal Create/Edit --}}
    <div
        x-show="modalOpen"
        x-cloak
        class="fixed inset-0 z-50 flex items-center justify-center px-4"
    >
        <div @click="modalOpen = false" class="absolute inset-0 bg-black/40"></div>

        <div class="relative bg-white border border-ink/10 w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
            <h2 class="font-display font-semibold text-lg mb-4" x-text="editing ? 'Edit Customer' : 'Tambah Customer'"></h2>

            <form @submit.prevent="submit()">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Nama</label>
                        <input type="text" x-model="form.name"
                               class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                        <p class="text-xs text-red-800 mt-1" x-text="errors.name?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">Telepon</label>
                        <input type="text" x-model="form.phone"
                               class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                        <p class="text-xs text-red-800 mt-1" x-text="errors.phone?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">Email</label>
                        <input type="email" x-model="form.email"
                               class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                        <p class="text-xs text-red-800 mt-1" x-text="errors.email?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">Alamat</label>
                        <textarea x-model="form.address" rows="3"
                                  class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40"></textarea>
                        <p class="text-xs text-red-800 mt-1" x-text="errors.address?.[0]"></p>
                    </div>
                </div>

                <div class="mt-6 flex justify-end gap-2">
                    <button type="button" @click="modalOpen = false"
                            class="text-sm px-4 py-2 border border-ink/15 hover:bg-ink/[0.03]">Batal</button>
                    <button type="submit" :disabled="saving"
                            class="text-sm px-4 py-2 bg-ink text-white hover:bg-ink/85 disabled:opacity-50">
                        <span x-text="saving ? 'Menyimpan...' : 'Simpan'"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function customerPage() {
        return {
            modalOpen: false,
            editing: null,
            saving: false,
            errors: {},
            flash: null,
            flashType: 'success',
            form: { name: '', phone: '', email: '', address: '' },

            openCreate() {
                this.editing = null;
                this.form = { name: '', phone: '', email: '', address: '' };
                this.errors = {};
                this.modalOpen = true;
            },

            openEdit(customer) {
                this.editing = customer;
                this.form = {
                    name: customer.name,
                    phone: customer.phone,
                    email: customer.email,
                    address: customer.address,
                };
                this.errors = {};
                this.modalOpen = true;
            },

            async submit() {
                this.saving = true;
                this.errors = {};

                const url = this.editing
                    ? `{{ url('customers') }}/${this.editing.id}`
                    : `{{ route('customers.store') }}`;
                const method = this.editing ? 'PUT' : 'POST';

                const { ok, status, data } = await window.ajaxSend(url, method, this.form);
                this.saving = false;

                if (ok) {
                    this.modalOpen = false;
                    this.flashType = 'success';
                    this.flash = data.message;
                    setTimeout(() => window.location.reload(), 500);
                    return;
                }

                if (status === 422) {
                    this.errors = data.errors || {};
                    return;
                }

                this.flashType = 'error';
                this.flash = data.message || 'Terjadi kesalahan.';
            },

            async remove(id) {
                if (!confirm('Hapus customer ini?')) return;

                const { ok, data } = await window.ajaxSend(`{{ url('customers') }}/${id}`, 'DELETE');

                this.flashType = ok ? 'success' : 'error';
                this.flash = data.message || (ok ? 'Berhasil dihapus.' : 'Gagal menghapus.');

                if (ok) setTimeout(() => window.location.reload(), 500);
            },
        };
    }
</script>
@endpush
