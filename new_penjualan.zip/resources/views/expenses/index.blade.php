@extends('layouts.app')

@section('page-title', 'Pengeluaran')

@section('content')
<div
    x-data="expensePage({{ Illuminate\Support\Js::from($expenseCategories) }})"
    x-cloak
>
    <div class="flex items-center justify-between mb-6">
        <p class="text-sm text-ink/50">{{ $expenses->total() }} catatan biaya</p>

        @if (auth()->user()->isSuperadmin())
            <button
                @click="openCreate()"
                class="text-sm font-medium bg-ink text-white px-4 py-2 hover:bg-ink/85 transition-colors"
            >
                + Tambah Biaya
            </button>
        @endif
    </div>

    <div x-show="flash" x-cloak class="mb-4 border text-sm px-4 py-3"
         :class="flashType === 'error' ? 'border-red-900/20 bg-red-50 text-red-900' : 'border-ink/10 bg-ink/[0.03]'">
        <span x-text="flash"></span>
    </div>

    <div class="border border-ink/10 overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-ink/10 text-left text-ink/50">
                    <th class="px-4 py-3 font-medium">Tanggal</th>
                    <th class="px-4 py-3 font-medium">Kategori</th>
                    <th class="px-4 py-3 font-medium">Keterangan</th>
                    <th class="px-4 py-3 font-medium text-right">Jumlah</th>
                    <th class="px-4 py-3 font-medium text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($expenses as $expense)
                    <tr class="border-b border-ink/10 last:border-0">
                        <td class="px-4 py-3 tnum">{{ $expense->expense_date->format('d/m/Y') }}</td>
                        <td class="px-4 py-3">{{ $expense->category->name }}</td>
                        <td class="px-4 py-3 text-ink/50">{{ $expense->description ?? '—' }}</td>
                        <td class="px-4 py-3 text-right tnum">Rp{{ number_format($expense->amount, 0, ',', '.') }}</td>
                        <td class="px-4 py-3 text-right">
                            @if (auth()->user()->isSuperadmin())
                                <button
                                    @click="openEdit({{ Illuminate\Support\Js::from($expense) }})"
                                    class="text-ink/60 hover:text-ink mr-3"
                                >Edit</button>
                                <button
                                    @click="remove({{ $expense->id }})"
                                    class="text-red-800/70 hover:text-red-900"
                                >Hapus</button>
                            @endif
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="px-4 py-6 text-center text-ink/40">Belum ada catatan biaya.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        {{ $expenses->links() }}
    </div>

    {{-- Modal Create/Edit --}}
    <div
        x-show="modalOpen"
        x-cloak
        class="fixed inset-0 z-50 flex items-center justify-center px-4"
    >
        <div @click="modalOpen = false" class="absolute inset-0 bg-black/40"></div>

        <div class="relative bg-white border border-ink/10 w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
            <h2 class="font-display font-semibold text-lg mb-4" x-text="editing ? 'Edit Biaya' : 'Tambah Biaya'"></h2>

            <form @submit.prevent="submit()">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Kategori Biaya</label>
                        <select x-model="form.expense_category_id"
                                class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                            <option value="">— Pilih kategori —</option>
                            <template x-for="cat in expenseCategories" :key="cat.id">
                                <option :value="cat.id" x-text="cat.name"></option>
                            </template>
                        </select>
                        <p class="text-xs text-red-800 mt-1" x-text="errors.expense_category_id?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">Tanggal</label>
                        <input type="date" x-model="form.expense_date"
                               class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                        <p class="text-xs text-red-800 mt-1" x-text="errors.expense_date?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">Jumlah (Rp)</label>
                        <input type="number" step="0.01" min="0" x-model="form.amount"
                               class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40 tnum">
                        <p class="text-xs text-red-800 mt-1" x-text="errors.amount?.[0]"></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium mb-1">Keterangan</label>
                        <input type="text" x-model="form.description"
                               class="w-full border border-ink/15 px-3 py-2 text-sm focus:outline-none focus:border-ink/40">
                        <p class="text-xs text-red-800 mt-1" x-text="errors.description?.[0]"></p>
                    </div>
                </div>

                <div class="mt-6 flex justify-end gap-2">
                    <button type="button" @click="modalOpen = false"
                            class="text-sm px-4 py-2 border border-ink/15 hover:bg-ink/[0.03]">Batal</button>
                    <button type="submit" :disabled="saving"
                            class="text-sm px-4 py-2 bg-ink text-white hover:bg-ink/85 disabled:opacity-50">
                        <span x-text="saving ? 'Menyimpan...' : 'Simpan'"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function expensePage(initialCategories) {
        return {
            expenseCategories: initialCategories,
            modalOpen: false,
            editing: null,
            saving: false,
            errors: {},
            flash: null,
            flashType: 'success',
            form: { expense_category_id: '', expense_date: '', amount: '', description: '' },

            openCreate() {
                this.editing = null;
                this.form = { expense_category_id: '', expense_date: '', amount: '', description: '' };
                this.errors = {};
                this.modalOpen = true;
            },

            openEdit(expense) {
                this.editing = expense;
                this.form = {
                    expense_category_id: expense.expense_category_id,
                    expense_date: expense.expense_date?.substring(0, 10),
                    amount: expense.amount,
                    description: expense.description,
                };
                this.errors = {};
                this.modalOpen = true;
            },

            async submit() {
                this.saving = true;
                this.errors = {};

                const url = this.editing
                    ? `{{ url('expenses') }}/${this.editing.id}`
                    : `{{ route('expenses.store') }}`;
                const method = this.editing ? 'PUT' : 'POST';

                const { ok, status, data } = await window.ajaxSend(url, method, this.form);
                this.saving = false;

                if (ok) {
                    this.modalOpen = false;
                    this.flashType = 'success';
                    this.flash = data.message;
                    setTimeout(() => window.location.reload(), 500);
                    return;
                }

                if (status === 422) {
                    this.errors = data.errors || {};
                    return;
                }

                this.flashType = 'error';
                this.flash = data.message || 'Terjadi kesalahan.';
            },

            async remove(id) {
                if (!confirm('Hapus catatan biaya ini?')) return;

                const { ok, data } = await window.ajaxSend(`{{ url('expenses') }}/${id}`, 'DELETE');

                this.flashType = ok ? 'success' : 'error';
                this.flash = data.message || (ok ? 'Berhasil dihapus.' : 'Gagal menghapus.');

                if (ok) setTimeout(() => window.location.reload(), 500);
            },
        };
    }
</script>
@endpush
