@extends('layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')

    <div class="mb-8">
        <p class="text-sm text-ink/50">Ringkasan periode {{ now()->translatedFormat('F Y') }}</p>
    </div>

    {{-- KPI utama --}}
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 border border-ink/10 divide-y sm:divide-y-0 sm:divide-x divide-ink/10 mb-6">

        <div class="p-6">
            <p class="text-xs text-ink/50 mb-2">Pendapatan Bulan Ini</p>
            <p class="font-display font-semibold text-2xl tnum">
                Rp {{ number_format($profitLoss['revenue'], 0, ',', '.') }}
            </p>
        </div>

        <div class="p-6">
            <p class="text-xs text-ink/50 mb-2">Laba Bersih</p>
            <p class="font-display font-semibold text-2xl tnum {{ $profitLoss['net_profit'] < 0 ? 'text-red-700' : '' }}">
                Rp {{ number_format($profitLoss['net_profit'], 0, ',', '.') }}
            </p>
        </div>

        <div class="p-6">
            <p class="text-xs text-ink/50 mb-2">Nilai Stok Saat Ini</p>
            <p class="font-display font-semibold text-2xl tnum">
                Rp {{ number_format($stockValue, 0, ',', '.') }}
            </p>
        </div>

        <div class="p-6">
            <p class="text-xs text-ink/50 mb-2">Kas Bersih Bulan Ini</p>
            <p class="font-display font-semibold text-2xl tnum {{ $cashFlow['net_cash'] < 0 ? 'text-red-700' : '' }}">
                Rp {{ number_format($cashFlow['net_cash'], 0, ',', '.') }}
            </p>
        </div>

    </div>

    {{-- Hutang / Piutang --}}
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">

        <a href="{{ route('reports.receivable') }}" class="block border border-ink/10 p-6 hover:border-ink/30 transition-colors">
            <div class="flex items-center justify-between mb-2">
                <p class="text-xs text-ink/50">Total Piutang (AR)</p>
                <span class="text-xs text-ink/40">Lihat detail &rarr;</span>
            </div>
            <p class="font-display font-semibold text-xl tnum">
                Rp {{ number_format($totalReceivable, 0, ',', '.') }}
            </p>
        </a>

        <a href="{{ route('reports.payable') }}" class="block border border-ink/10 p-6 hover:border-ink/30 transition-colors">
            <div class="flex items-center justify-between mb-2">
                <p class="text-xs text-ink/50">Total Hutang (AP)</p>
                <span class="text-xs text-ink/40">Lihat detail &rarr;</span>
            </div>
            <p class="font-display font-semibold text-xl tnum">
                Rp {{ number_format($totalPayable, 0, ',', '.') }}
            </p>
        </a>

    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {{-- Ringkasan Laba Rugi --}}
        <div class="lg:col-span-2 border border-ink/10">
            <div class="px-6 py-4 border-b border-ink/10">
                <h2 class="font-display font-semibold">Ringkasan Laba Rugi</h2>
            </div>
            <div class="divide-y divide-ink/10 text-sm">
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="text-ink/60">Pendapatan Penjualan</span>
                    <span class="tnum">Rp {{ number_format($profitLoss['revenue'], 0, ',', '.') }}</span>
                </div>
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="text-ink/60">HPP (FIFO)</span>
                    <span class="tnum">Rp {{ number_format($profitLoss['hpp'], 0, ',', '.') }}</span>
                </div>
                <div class="flex items-center justify-between px-6 py-3 font-medium">
                    <span>Laba Kotor</span>
                    <span class="tnum">Rp {{ number_format($profitLoss['gross_profit'], 0, ',', '.') }}</span>
                </div>
                <div class="flex items-center justify-between px-6 py-3">
                    <span class="text-ink/60">Biaya Operasional</span>
                    <span class="tnum">Rp {{ number_format($profitLoss['operational_expense'], 0, ',', '.') }}</span>
                </div>
                <div class="flex items-center justify-between px-6 py-3 font-semibold bg-ink/[0.03]">
                    <span>Laba Bersih</span>
                    <span class="tnum">Rp {{ number_format($profitLoss['net_profit'], 0, ',', '.') }}</span>
                </div>
            </div>
        </div>

        {{-- Stok menipis --}}
        <div class="border border-ink/10">
            <div class="px-6 py-4 border-b border-ink/10">
                <h2 class="font-display font-semibold">Stok Menipis</h2>
            </div>
            @if ($lowStockProducts->isEmpty())
                <p class="px-6 py-8 text-sm text-ink/40 text-center">Tidak ada produk dengan stok rendah.</p>
            @else
                <div class="divide-y divide-ink/10 text-sm">
                    @foreach ($lowStockProducts as $product)
                        <div class="flex items-center justify-between px-6 py-3">
                            <div class="min-w-0">
                                <p class="truncate">{{ $product->name }}</p>
                                <p class="text-xs text-ink/40">{{ $product->sku }}</p>
                            </div>
                            <span class="tnum font-medium {{ $product->qty_on_hand == 0 ? 'text-red-700' : '' }}">
                                {{ $product->qty_on_hand }}
                            </span>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>

    </div>

@endsection
